package appwhatsapp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JOptionPane;

public class ArquivoSerializado {

    private File f;

    public ArquivoSerializado(String nomeArquivo) {
        f = new File(nomeArquivo);
    }
    
    public WhatsApp lerArquivo(){
        WhatsApp wp;
        if(f.exists()){
            try (FileInputStream arquivoLeitura = new FileInputStream(f);
                    ObjectInputStream objLeitura = new ObjectInputStream(arquivoLeitura);){
                wp = (WhatsApp) objLeitura.readObject();
            }catch (Exception ex){
                JOptionPane.showMessageDialog(null, ex);
                wp = new WhatsApp();
            }
        }else{
            JOptionPane.showMessageDialog(null, "Não existia arquivo");
            wp = new WhatsApp();
        }
        return wp;
    }
    
    public void gravarArquivo(WhatsApp wp){
        try (FileOutputStream arquivoGravar = new FileOutputStream(f);
                ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGravar)){
            objGravar.writeObject(wp);
            objGravar.flush();
            objGravar.close();
            arquivoGravar.flush();
            arquivoGravar.close();
            JOptionPane.showMessageDialog(null, "Objeto gravado com sucesso!");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }

}
