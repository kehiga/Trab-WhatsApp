package appwhatsapp;

import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class WhatsApp implements Serializable {

    private ArrayList<Conversa> conversa = new ArrayList();
    private String nomeUsuario;
    private String meuTelefone = "(11)2345-6789";//telefone nosso

    public ArrayList<Conversa> getConversa() {
        return conversa;
    }
    
    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public String getMeuTelefone() {
        return meuTelefone;
    }

    public Conversa iniciarConversa(String telefoneContato) {
        for (Conversa c : conversa) {
            if (c.getContato().equalsIgnoreCase(telefoneContato)) {
                JOptionPane.showMessageDialog(null, "Já existe conversa com esse contato!");
                return c;
            }
        }
        Conversa c = new Conversa();
        c.setContato(telefoneContato);
        conversa.add(c);
        return c;
    }

    public void mandarMensagem(String contato, String texto) {
        receberMensagem(contato, texto);
    }

    public void receberMensagem(String contato, String texto) {
        Conversa c = new Conversa();
        c.adicionarConversa(nomeUsuario, texto);
    }

    public void conversaContato(String telefone) {
        for (Conversa c : conversa) {
            if (c.getContato().equalsIgnoreCase(telefone)) {
                c.retornarConversa();
            }
        }
    }
}
