package appwhatsapp;

import java.io.Serializable;
import java.util.ArrayList;

//armazena as mensagens
public class Conversa implements Serializable{

    private ArrayList<Mensagem> mensagem = new ArrayList();
    //telefone do outro participante
    private String contato;
    private String ultimaVisualizacao;

    public ArrayList<Mensagem> getMensagem() {
        return mensagem;
    }
    
    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getUltimaVisualizacao() {
        return ultimaVisualizacao;
    }

    public void setUltimaVisualizacao(String ultimaVisualizacao) {
        this.ultimaVisualizacao = ultimaVisualizacao;
    }

    public void adicionarConversa(String autorMensagem, String texto) {
        mensagem.add(new Mensagem(autorMensagem, texto));
    }

    public ArrayList<Mensagem> buscarPalavraChave(String palavraChave) {
        ArrayList<Mensagem> saida = new ArrayList();
        
        for (int i = 0; i < mensagem.size(); i++) {
            String[] breakLine = mensagem.get(i).getTexto().split(" ");
            for (int j = 0; j < breakLine.length; j++) {
                if(breakLine[j].equalsIgnoreCase(palavraChave)){
                    saida.add(mensagem.get(i));
                }
            }
        }
//        Mensagem x = new Mensagem();
//        ArrayList<Mensagem> chave = new ArrayList();
//        String[] message = x.getTexto().split("\n");
//        String[] palavra;
//        
//        for (int i = 0; i < message.length; i++) {
//            palavra = message[i].split(" ");
//            for (int j = 0; j < palavra.length; j++) {
//                if (palavra[i].equalsIgnoreCase(palavraChave)) {
//                    chave.add(x);
//                }
//            }
//        }
//        return chave;
        return saida;
    }

    public ArrayList<Mensagem> retornarConversa() {
        return mensagem;
    }
}
